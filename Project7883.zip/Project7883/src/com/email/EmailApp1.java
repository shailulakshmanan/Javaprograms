package com.email;

public class EmailApp1 {

	public static void main(String[] args) {
		EmailApplication em1 = new EmailApplication("shailu","lakshmanan");
		em1.userInput();
		em1.setAlternateEmail("ALTERNATE EMAIL:Rishita mohan@gmail.com");
		System.out.println(em1.getAlternateEmail());
		
		System.out.println(em1.showInfo());
		
}

}
