/*
  This program executes the email id with your first name and last name ,
  password with mailbox capacity
 */
package com.email;
import java.util.Scanner;

public class EmailApplication {

	private String firstName;
	private String lastName;
	private String password;
	private String department;
	private int mailboxcapacity;
	private String email;
	private int defaultPasswordLength;
	private String AlternateEmail;
	private String companySuffix ="company.com";
	
	// constructor to receive first name and last name
	
	public EmailApplication(String firstName,String lastName){
		this.firstName = firstName;
		this.lastName = lastName;	
		this.mailboxcapacity =500;
		this.defaultPasswordLength=10;
		
		//call a method asking for the department - return the department
		this.department = setDepartment();
		System.out.println("Department: "+ this.department);
		
		
		//call a method that returns a random password
		this.password = randomPassword(defaultPasswordLength);
		System.out.println("Your password is:"+ this.password);
		
		//combine elements to generate email
		email = firstName.toLowerCase() + "."+lastName.toLowerCase() +"@" + department + "."+
		companySuffix;
		System.out.println("your email is: " + email);
	
	}
	//getting input from the user
	public void userInput() {
		

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the first name");
		firstName = sc.nextLine();
		System.out.println("enter the last name");
		lastName = sc.nextLine();
		

	}
	
	
		//ask for the department
	private String setDepartment() {
		System.out.println("New worker: " + firstName + ". Department codes:\n1 for Sales\n2"
				+ " for Development\n3 for accounting\n0 for none\nEnter department code:");
		Scanner in = new Scanner(System.in);
		int depChoice = in.nextInt();
		if(depChoice == 1) {
			return "sales";
		}
		else if(depChoice == 2) {
			return "development";
		}
	else if(depChoice == 3) {
		return " accounting";
	}else if(depChoice ==0){
		return "none";
	}else {
		return "";
	}
	}
		//Generate a random password
		private String randomPassword(int length) {
			String passwordSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%";
			char[] password = new char[length];
			for(int i=0;i<length;i++) {
				int rand =(int)	(Math.random() * passwordSet.length());
				password[i]=passwordSet.charAt(rand);
			}
			return new String (password);
		}
		// set the mailbox capacity
		public void setMailboxCapacit(int capacity) {
			this.mailboxcapacity = capacity;
		}
		// set the alternate email
		public void setAlternateEmail(String altEmail) {
			this.AlternateEmail = altEmail;
		}
		// change the password
		public void changePassword(String password) {
			this.password = password;
		}
		public int getMailboxCapacity() { return mailboxcapacity;}
		public String getAlternateEmail() {return AlternateEmail;}
		public String getPassword(){return password;}
		
		public String showInfo() {
			return "DISPLAY NAME: " + firstName + "" + lastName +
					"\nCOMPANY EMAIL:" + email + 
					"\nMAILBOX CAPACITY:" + mailboxcapacity + "mb";
		}
		
			
		}
		

	


